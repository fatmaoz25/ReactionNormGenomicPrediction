#### PHK76 ####
rm(list = ls())
pheno <- read.csv("Yield.wide.csv")
pheno <- pheno[,-c(1,14,29,50)]
pheno <- reshape2::melt(pheno, id.var = c('Inbred'), variable.name = 'Tester_Env')
pheno <- tidyr::separate(pheno, col=Tester_Env, into=c('Tester', 'Env'), sep='_')


pheno <- pheno[pheno$Tester=="PHK76",]
pheno <- pheno[,-2]
names(pheno)[1:3] <- c("inbred", "env", "yield")
head(pheno)

library(dplyr)
df<- read.csv("Yield.wide.csv")


##### GRM #####
# Check that the pedigrees were stacked after being sorted the same way in each environment
env <- unique(pheno$env)
for (envir in env) {
  test1 <- pheno %>% filter(env == 'DEH1.2020')
  test2 <- pheno %>% filter(env == envir)
  print(sum(test1$inbred == test2$inbred))
}

geno <- data.table::fread("cm.mbp.ss.100k.sites.SSpopulation_geno.csv") %>% as.data.frame()
row.names(geno) <- geno$lines
geno <- geno[,-1]


# Check that the pedigrees in the geno file are in the same order as the pheno file
sum(rownames(geno) == test2$inbred)
geno <- rrBLUP::A.mat(geno, min.MAF = 0.05, impute.method = "EM",  tol = 0.02,n.core = 10,shrink = FALSE,  return.imputed = T)

# Single-env GRM
ZG_single <- geno$A

# The GRM is the same for each environment since the same 174 pedigrees were used and are in the same order
# We need to create a 1914 x 1914 ZG matrix where each 174 x 174 block is the same additive GRM calculated from rrBLUP
ZG_list <- list(ZG_single, ZG_single, ZG_single, ZG_single, ZG_single,
                ZG_single, ZG_single, ZG_single, ZG_single, ZG_single,
                ZG_single)
ZG_stack <- do.call(rbind, ZG_list)
dim(ZG_stack)

# Initialize ZG
ZG <- ZG_stack

# We need 10 more copies of ZG_stack (add them to the right side of ZG)
for (i in 1:10) {
  ZG <- cbind(ZG, ZG_stack)
}
dim(ZG)


##### Environment kernel #####
pheno$env <- as.factor(pheno$env)
ZE<-model.matrix(~pheno$env-1)
ZE[1:10,1:11]
dim(ZE)

# Environment incidence matrix
ZEZE   <- tcrossprod(ZE)

# Multi-environment GRM
ZGZE   <- ZG*ZEZE # Block diagonal environment incidence matrix

# Environment incidence matrix, GRM, and GxE
Eta1 <- list(E=list(X=ZE, model="BRR"),
             G=list(K=ZG, model="RKHS"),
             EG=list(K=ZGZE, model="RKHS"))

Models <- list(Eta1)

CV1 <- list()
CV2 <- list()
CV0 <- list()
CV00 <- list()

library(BGLR)
library(MASS)
library(parallel)
library(doParallel)

env <- unique(pheno$env)

Reps <- rep('Rep.', times = 100)
Reps <- paste0(Reps, seq(1, 100, by = 1))

numCores <- detectCores()
numCores
registerDoParallel(numCores-1)

foreach(MODEL = 1:length(Models), .packages = c('BGLR', 'dplyr')) %dopar% {
  
  for (rep.num in Reps)
  {
    for (envir in env)
    {
      
      print(paste('Untested env:', envir, rep.num, sep = ' '))
      
      untested.env <- envir
      
      df <- pheno
      df$Y2 <- df$yield
      hybrids <- unique(df$inbred)
      
      train_hybrids <- sample(hybrids, size = length(hybrids) * 0.7)
      test_hybrids <- hybrids[!hybrids %in% train_hybrids]
      
      # Set test hybrid yield values as NA throughout whole data frame (use Y2 for CV2/CV1)
      df$Y2[df$inbred%in%test_hybrids] <- NA
      
      # Set ALL yield values within current untested environment as NA (use Y3 for CV0/00)
      df$Y3 <- df$Y2
      df$Y3[pheno$env == untested.env] <- NA
      
      # Response values for each CV scheme
      y_cv_2_1 <- as.numeric(df$Y2) # Training hybrids occur in all environments
      y_cv_0_00 <- as.numeric(df$Y3) # Training hybrids occur in all environments except the untested location
      
      
      ###### CV2 and CV1 ######
      # Fit the model for CV2 and CV1
      fit_cv_2_1 <- BGLR(y = y_cv_2_1, ETA = Eta1, nIter = 10000, burnIn = 1000)
      # Save y-hat values for CV2 and CV1
      df$cv2_1_yhat <- fit_cv_2_1$yHat
      
      # Create data frames to use for calculating correlations
      train_cv_2_1 <- df[df$inbred %in% train_hybrids & !df$env == untested.env, ]
      test_cv_2_1 <- df[df$inbred %in% test_hybrids & !df$env == untested.env, ]
      
      # Calculate and save the correlations
      CV2[[paste(rep.num, envir, sep = '.')]] <- train_cv_2_1 %>% group_by(env) %>% summarize(cor=cor(yield, cv2_1_yhat, use = 'complete.obs')) %>% as.data.frame()
      CV1[[paste(rep.num, envir, sep = '.')]] <- test_cv_2_1 %>% group_by(env) %>% summarize(cor=cor(yield, cv2_1_yhat, use = 'complete.obs')) %>% as.data.frame()
      write.csv(CV2[[paste(rep.num, envir, sep = '.')]], file = paste(rep.num, envir, 'CV2', 'PHK76', 'csv', sep = '.'))
      write.csv(CV1[[paste(rep.num, envir, sep = '.')]], file = paste(rep.num, envir, 'CV1', 'PHK76', 'csv', sep = '.'))
      
      
      ##### CV0 and CV00 #####
      # Fit the model for CV0 and CV00
      fit_cv_0_00 <- BGLR(y = y_cv_0_00, ETA = Eta1, nIter = 10000, burnIn = 1000)
      # Save y-hat values for CV0 and CV00
      df$cv_0_00_yhat <- fit_cv_0_00$yHat
      
      # Create data frames to use for calculating correlations
      train_cv_0_00 <- df[df$inbred %in% train_hybrids & df$env == untested.env, ]
      test_cv_0_00 <- df[df$inbred %in% test_hybrids & df$env == untested.env, ]
      
      # Calculate and save the correlations
      CV0[[paste(rep.num, envir, sep = '.')]] <- train_cv_0_00 %>% group_by(env) %>% summarize(cor=cor(yield, cv_0_00_yhat, use = 'complete.obs')) %>% as.data.frame()
      CV00[[paste(rep.num, envir, sep = '.')]] <- test_cv_0_00 %>% group_by(env) %>% summarize(cor=cor(yield, cv_0_00_yhat, use = 'complete.obs')) %>% as.data.frame()    
      write.csv(CV0[[paste(rep.num, envir, sep = '.')]], file = paste(rep.num, envir, 'CV0', 'PHK76', 'csv', sep = '.'))
      write.csv(CV00[[paste(rep.num, envir, sep = '.')]], file = paste(rep.num, envir, 'CV00', 'PHK76', 'csv', sep = '.'))
      
      
    }
    
  }
  
}

CV1.phk76 <- plyr::ldply(CV1, data.frame)
CV2.phk76 <- plyr::ldply(CV2, data.frame)
CV0.phk76 <- plyr::ldply(CV0, data.frame)
CV00.phk76 <- plyr::ldply(CV00, data.frame)

write.csv(CV1.phk76, "CV1.phk76G.csv")
write.csv(CV2.phk76, "CV2.phk76G.csv")
write.csv(CV0.phk76, "CV0.phk76G.csv")
write.csv(CV00.phk76, "CV00.phk76G.csv")


#### PHP02 ####
rm(list = ls())
pheno <- read.csv("Yield.wide.csv")
pheno <- pheno[,-c(1,14,29,50)]
pheno <- reshape2::melt(pheno, id.var = c('Inbred'), variable.name = 'Tester_Env')
pheno <- tidyr::separate(pheno, col=Tester_Env, into=c('Tester', 'Env'), sep='_')


pheno <- pheno[pheno$Tester=="PHP02",]
pheno <- pheno[,-2]
names(pheno)[1:3] <- c("inbred", "env", "yield")
head(pheno)

library(dplyr)
df<- read.csv("Yield.wide.csv")


##### GRM #####
# Check that the pedigrees were stacked after being sorted the same way in each environment
env <- unique(pheno$env)
for (envir in env) {
  test1 <- pheno %>% filter(env == 'DEH1.2021')
  test2 <- pheno %>% filter(env == envir)
  print(sum(test1$inbred == test2$inbred))
}

geno <- data.table::fread("cm.mbp.ss.100k.sites.SSpopulation_geno.csv") %>% as.data.frame()
row.names(geno) <- geno$lines
geno <- geno[,-1]

# Check that the pedigrees in the geno file are in the same order as the pheno file
sum(rownames(geno) == test2$inbred)
geno <- rrBLUP::A.mat(geno, min.MAF = 0.05, impute.method = "EM",  tol = 0.02,n.core = 10,shrink = FALSE,  return.imputed = T)

# Single-env GRM
ZG_single <- geno$A

# The GRM is the same for each environment since the same 174 pedigrees were used and are in the same order
# We need to create a 2262 x 2262 ZG matrix where each 174 x 174 block is the same additive GRM calculated from rrBLUP
ZG_list <- list(ZG_single, ZG_single, ZG_single, ZG_single, ZG_single,
                ZG_single, ZG_single, ZG_single, ZG_single, ZG_single,
                ZG_single, ZG_single, ZG_single)
ZG_stack <- do.call(rbind, ZG_list)
dim(ZG_stack)

# Initialize ZG
ZG <- ZG_stack

# We need 12 more copies of ZG_stack (add them to the right side of ZG)
for (i in 1:12) {
  ZG <- cbind(ZG, ZG_stack)
}
dim(ZG)


##### Environment kernel #####
pheno$env <- as.factor(pheno$env)
ZE<-model.matrix(~pheno$env-1)
ZE[1:10,1:11]
dim(ZE)

# Environment incidence matrix
ZEZE   <- tcrossprod(ZE)

# Multi-environment GRM
ZGZE   <- ZG*ZEZE # Block diagonal environment incidence matrix

# Environment incidence matrix, GRM, and GxE
Eta1 <- list(E=list(X=ZE, model="BRR"),
             G=list(K=ZG, model="RKHS"),
             EG=list(K=ZGZE, model="RKHS"))

Models <- list(Eta1)

CV1 <- list()
CV2 <- list()
CV0 <- list()
CV00 <- list()

library(BGLR)
library(MASS)
library(parallel)
library(doParallel)

env <- unique(pheno$env)

Reps <- rep('Rep.', times = 100)
Reps <- paste0(Reps, seq(1, 100, by = 1))

numCores <- detectCores()
numCores
registerDoParallel(numCores-1)

foreach(MODEL = 1:length(Models), .packages = c('BGLR', 'dplyr')) %dopar% {
  
  for (rep.num in Reps)
  {
    for (envir in env)
    {
      
      print(paste('Untested env:', envir, rep.num, sep = ' '))
      
      untested.env <- envir
      
      df <- pheno
      df$Y2 <- df$yield
      hybrids <- unique(df$inbred)
      
      train_hybrids <- sample(hybrids, size = length(hybrids) * 0.7)
      test_hybrids <- hybrids[!hybrids %in% train_hybrids]
      
      # Set test hybrid yield values as NA throughout whole data frame (use Y2 for CV2/CV1)
      df$Y2[df$inbred%in%test_hybrids] <- NA
      
      # Set ALL yield values within current untested environment as NA (use Y3 for CV0/00)
      df$Y3 <- df$Y2
      df$Y3[pheno$env == untested.env] <- NA
      
      # Response values for each CV scheme
      y_cv_2_1 <- as.numeric(df$Y2) # Training hybrids occur in all environments
      y_cv_0_00 <- as.numeric(df$Y3) # Training hybrids occur in all environments except the untested location
      
      
      ###### CV2 and CV1 ######
      # Fit the model for CV2 and CV1
      fit_cv_2_1 <- BGLR(y = y_cv_2_1, ETA = Eta1, nIter = 10000, burnIn = 1000)
      # Save y-hat values for CV2 and CV1
      df$cv2_1_yhat <- fit_cv_2_1$yHat
      
      # Create data frames to use for calculating correlations
      train_cv_2_1 <- df[df$inbred %in% train_hybrids & !df$env == untested.env, ]
      test_cv_2_1 <- df[df$inbred %in% test_hybrids & !df$env == untested.env, ]
      
      # Calculate and save the correlations
      CV2[[paste(rep.num, envir, sep = '.')]] <- train_cv_2_1 %>% group_by(env) %>% summarize(cor=cor(yield, cv2_1_yhat, use = 'complete.obs')) %>% as.data.frame()
      CV1[[paste(rep.num, envir, sep = '.')]] <- test_cv_2_1 %>% group_by(env) %>% summarize(cor=cor(yield, cv2_1_yhat, use = 'complete.obs')) %>% as.data.frame()
      write.csv(CV2[[paste(rep.num, envir, sep = '.')]], file = paste(rep.num, envir, 'CV2', 'PHP02', 'csv', sep = '.'))
      write.csv(CV1[[paste(rep.num, envir, sep = '.')]], file = paste(rep.num, envir, 'CV1', 'PHP02', 'csv', sep = '.'))
      
      
      ##### CV0 and CV00 #####
      # Fit the model for CV0 and CV00
      fit_cv_0_00 <- BGLR(y = y_cv_0_00, ETA = Eta1, nIter = 10000, burnIn = 1000)
      # Save y-hat values for CV0 and CV00
      df$cv_0_00_yhat <- fit_cv_0_00$yHat
      
      # Create data frames to use for calculating correlations
      train_cv_0_00 <- df[df$inbred %in% train_hybrids & df$env == untested.env, ]
      test_cv_0_00 <- df[df$inbred %in% test_hybrids & df$env == untested.env, ]
      
      # Calculate and save the correlations
      CV0[[paste(rep.num, envir, sep = '.')]] <- train_cv_0_00 %>% group_by(env) %>% summarize(cor=cor(yield, cv_0_00_yhat, use = 'complete.obs')) %>% as.data.frame()
      CV00[[paste(rep.num, envir, sep = '.')]] <- test_cv_0_00 %>% group_by(env) %>% summarize(cor=cor(yield, cv_0_00_yhat, use = 'complete.obs')) %>% as.data.frame()    
      write.csv(CV0[[paste(rep.num, envir, sep = '.')]], file = paste(rep.num, envir, 'CV0', 'PHP02', 'csv', sep = '.'))
      write.csv(CV00[[paste(rep.num, envir, sep = '.')]], file = paste(rep.num, envir, 'CV00', 'PHP02', 'csv', sep = '.'))
      
      
    }
    
  }
  
}

CV1.php02 <- plyr::ldply(CV1, data.frame)
CV2.php02 <- plyr::ldply(CV2, data.frame)
CV0.php02 <- plyr::ldply(CV0, data.frame)
CV00.php02 <- plyr::ldply(CV00, data.frame)

write.csv(CV1.php02, "CV1.php02G.csv")
write.csv(CV2.php02, "CV2.php02G.csv")
write.csv(CV0.php02, "CV0.php02G.csv")
write.csv(CV00.php02, "CV00.php02G.csv")


#### PHZ51 ####
rm(list = ls())
pheno <- read.csv("Yield.wide.csv")
pheno <- pheno[,-c(1,14,29,50)]
pheno <- reshape2::melt(pheno, id.var = c('Inbred'), variable.name = 'Tester_Env')
pheno <- tidyr::separate(pheno, col=Tester_Env, into=c('Tester', 'Env'), sep='_')


pheno <- pheno[pheno$Tester=="PHZ51",]
pheno <- pheno[,-2]
names(pheno)[1:3] <- c("inbred", "env", "yield")
head(pheno)

library(dplyr)
df<- read.csv("Yield.wide.csv")

##### GRM #####
# Check that the pedigrees were stacked after being sorted the same way in each environment
env <- unique(pheno$env)
for (envir in env) {
  test1 <- pheno %>% filter(env == 'DEH1.2020')
  test2 <- pheno %>% filter(env == envir)
  print(sum(test1$inbred == test2$inbred))
}

geno <- data.table::fread("cm.mbp.ss.100k.sites.SSpopulation_geno.csv") %>% as.data.frame()
row.names(geno) <- geno$lines
geno <- geno[,-1]

# Check that the pedigrees in the geno file are in the same order as the pheno file
sum(rownames(geno) == test2$inbred)
geno <- rrBLUP::A.mat(geno, min.MAF = 0.05, impute.method = "EM",  tol = 0.02,n.core = 10,shrink = FALSE,  return.imputed = T)

# Single-env GRM
ZG_single <- geno$A

# The GRM is the same for each environment since the same 174 pedigrees were used and are in the same order
# We need to create a 3306 x 3306 ZG matrix where each 174 x 174 block is the same additive GRM calculated from rrBLUP
ZG_list <- list(ZG_single, ZG_single, ZG_single, ZG_single, ZG_single,
                ZG_single, ZG_single, ZG_single, ZG_single, ZG_single,
                ZG_single, ZG_single, ZG_single, ZG_single, ZG_single,
                ZG_single, ZG_single, ZG_single, ZG_single)
ZG_stack <- do.call(rbind, ZG_list)
dim(ZG_stack)

# Initialize ZG
ZG <- ZG_stack

# We need 18 more copies of ZG_stack (add them to the right side of ZG)
for (i in 1:18) {
  ZG <- cbind(ZG, ZG_stack)
}
dim(ZG)


##### Environment kernel #####
pheno$env <- as.factor(pheno$env)
ZE<-model.matrix(~pheno$env-1)
ZE[1:10,1:11]
dim(ZE)

# Environment incidence matrix
ZEZE   <- tcrossprod(ZE)

# Multi-environment GRM
ZGZE   <- ZG*ZEZE # Block diagonal environment incidence matrix

# Environment incidence matrix, GRM, and GxE
Eta1 <- list(E=list(X=ZE, model="BRR"),
             G=list(K=ZG, model="RKHS"),
             EG=list(K=ZGZE, model="RKHS"))

Models <- list(Eta1)

CV1 <- list()
CV2 <- list()
CV0 <- list()
CV00 <- list()

library(BGLR)
library(MASS)
library(parallel)
library(doParallel)

env <- unique(pheno$env)

Reps <- rep('Rep.', times = 100)
Reps <- paste0(Reps, seq(1, 100, by = 1))

numCores <- detectCores()
numCores
registerDoParallel(numCores-1)

foreach(MODEL = 1:length(Models), .packages = c('BGLR', 'dplyr')) %dopar% {
  
  for (rep.num in Reps)
  {
    for (envir in env)
    {
      
      print(paste('Untested env:', envir, rep.num, sep = ' '))
      
      untested.env <- envir
      
      df <- pheno
      df$Y2 <- df$yield
      hybrids <- unique(df$inbred)
      
      train_hybrids <- sample(hybrids, size = length(hybrids) * 0.7)
      test_hybrids <- hybrids[!hybrids %in% train_hybrids]
      
      # Set test hybrid yield values as NA throughout whole data frame (use Y2 for CV2/CV1)
      df$Y2[df$inbred%in%test_hybrids] <- NA
      
      # Set ALL yield values within current untested environment as NA (use Y3 for CV0/00)
      df$Y3 <- df$Y2
      df$Y3[pheno$env == untested.env] <- NA
      
      # Response values for each CV scheme
      y_cv_2_1 <- as.numeric(df$Y2) # Training hybrids occur in all environments
      y_cv_0_00 <- as.numeric(df$Y3) # Training hybrids occur in all environments except the untested location
      
      
      ###### CV2 and CV1 ######
      # Fit the model for CV2 and CV1
      fit_cv_2_1 <- BGLR(y = y_cv_2_1, ETA = Eta1, nIter = 10000, burnIn = 1000)
      # Save y-hat values for CV2 and CV1
      df$cv2_1_yhat <- fit_cv_2_1$yHat
      
      # Create data frames to use for calculating correlations
      train_cv_2_1 <- df[df$inbred %in% train_hybrids & !df$env == untested.env, ]
      test_cv_2_1 <- df[df$inbred %in% test_hybrids & !df$env == untested.env, ]
      
      # Calculate and save the correlations
      CV2[[paste(rep.num, envir, sep = '.')]] <- train_cv_2_1 %>% group_by(env) %>% summarize(cor=cor(yield, cv2_1_yhat, use = 'complete.obs')) %>% as.data.frame()
      CV1[[paste(rep.num, envir, sep = '.')]] <- test_cv_2_1 %>% group_by(env) %>% summarize(cor=cor(yield, cv2_1_yhat, use = 'complete.obs')) %>% as.data.frame()
      write.csv(CV2[[paste(rep.num, envir, sep = '.')]], file = paste(rep.num, envir, 'CV2', 'PHZ51', 'csv', sep = '.'))
      write.csv(CV1[[paste(rep.num, envir, sep = '.')]], file = paste(rep.num, envir, 'CV1', 'PHZ51', 'csv', sep = '.'))
      
      
      ##### CV0 and CV00 #####
      # Fit the model for CV0 and CV00
      fit_cv_0_00 <- BGLR(y = y_cv_0_00, ETA = Eta1, nIter = 10000, burnIn = 1000)
      # Save y-hat values for CV0 and CV00
      df$cv_0_00_yhat <- fit_cv_0_00$yHat
      
      # Create data frames to use for calculating correlations
      train_cv_0_00 <- df[df$inbred %in% train_hybrids & df$env == untested.env, ]
      test_cv_0_00 <- df[df$inbred %in% test_hybrids & df$env == untested.env, ]
      
      # Calculate and save the correlations
      CV0[[paste(rep.num, envir, sep = '.')]] <- train_cv_0_00 %>% group_by(env) %>% summarize(cor=cor(yield, cv_0_00_yhat, use = 'complete.obs')) %>% as.data.frame()
      CV00[[paste(rep.num, envir, sep = '.')]] <- test_cv_0_00 %>% group_by(env) %>% summarize(cor=cor(yield, cv_0_00_yhat, use = 'complete.obs')) %>% as.data.frame()    
      write.csv(CV0[[paste(rep.num, envir, sep = '.')]], file = paste(rep.num, envir, 'CV0', 'PHZ51', 'csv', sep = '.'))
      write.csv(CV00[[paste(rep.num, envir, sep = '.')]], file = paste(rep.num, envir, 'CV00', 'PHZ51', 'csv', sep = '.'))
      
      
    }
    
  }
  
}

CV1.phz51 <- plyr::ldply(CV1, data.frame)
CV2.phz51 <- plyr::ldply(CV2, data.frame)
CV0.phz51 <- plyr::ldply(CV0, data.frame)
CV00.phz51 <- plyr::ldply(CV00, data.frame)

write.csv(CV1.phz51, "CV1.phz51G.csv")
write.csv(CV2.phz51, "CV2.phz51G.csv")
write.csv(CV0.phz51, "CV0.phz51G.csv")
write.csv(CV00.phz51, "CV00.phz51G.csv")