# Define the folder path
folder_path <- "D:/Fatma/Env Index Manuscript/Redo_RegressionMean/combined_results"
folder_path2 <- "C:\\Users\\fatma\\OneDrive\\Documents\\combined_results"
# Get all CSV files in the folder
file_list <- list.files(path = folder_path, pattern = "*.csv", full.names = TRUE)
file_list2 <- list.files(path = folder_path2, pattern = "*.csv", full.names = TRUE)
# Get list of all CSV files in the folder
file_list <- list.files(path = folder_path, pattern = "*.csv", full.names = TRUE)

# Function to rename files
rename_files <- function(file_path) {
  file_name <- basename(file_path)  # Extract file name from full path
  
  # Use regex to insert a period before the environment (e.g., "1DEH1" -> "1.DEH1")
  new_file_name <- sub("([0-9]+)([A-Z]+[0-9]*)", "\\1.\\2", file_name)
  
  # Define the new file path
  new_file_path <- file.path(folder_path, new_file_name)
  
  # Rename the file if the name has changed
  if (file_name != new_file_name) {
    file.rename(file_path, new_file_path)
    message(paste("Renamed:", file_name, "->", new_file_name))
  }
}

# Apply renaming function to all files
sapply(file_list, rename_files)



#########################################

library(dplyr)
library(readr)
library(stringr)

# Set the directory containing the CSV files
folder_path <- "D:/Fatma/Env Index Manuscript/Redo_RegressionMean/combined_results"

# List all CSV files in the folder
file_list <- list.files(folder_path, pattern = "*.csv", full.names = TRUE)

# Function to extract CV and Tester from the filename
extract_info <- function(file_path) {
  file_name <- basename(file_path)  # Get filename only
  
  # Extract CV (CV00, CV1, etc.)
  cv_match <- str_extract(file_name, "CV[0-9]+")
  
  # Extract Tester (e.g., PHK76) - assuming it's the last part before ".csv"
  tester_match <- str_extract(file_name, "[A-Z]+[0-9]+(?=\\.csv)")
  
  return(list(cv = cv_match, tester = tester_match))
}

# Function to process each file
process_file <- function(file_path) {
  df <- read_csv(file_path, show_col_types = FALSE)  # Read CSV
  
  # Extract CV and Tester from filename
  file_info <- extract_info(file_path)
  
  # Add extracted columns
  df <- df %>%
    mutate(CV = file_info$cv, 
           Tester = file_info$tester)
  
  return(df)
}

# Apply function to all files and combine into one dataframe
all_data <- bind_rows(lapply(file_list, process_file))


#######
folder_path2 <- "C:\\Users\\fatma\\OneDrive\\Documents\\combined_results"
file_list2 <- list.files(path = folder_path2, pattern = "*.csv", full.names = TRUE)


# Function to extract CV and Tester from the filename
extract_info <- function(file_path2) {
  file_name2 <- basename(file_path2)  # Get filename only
  
  # Extract CV (CV00, CV1, etc.)
  cv_match2 <- str_extract(file_name2, "CV[0-9]+")
  
  # Extract Tester (e.g., PHK76) - assuming it's the last part before ".csv"
  tester_match2 <- str_extract(file_name2, "[A-Z]+[0-9]+(?=\\.csv)")
  
  return(list(cv = cv_match2, tester = tester_match2))
}

# Function to process each file
process_file2 <- function(file_path2) {
  df2 <- read_csv(file_path2, show_col_types = FALSE)  # Read CSV
  
  # Extract CV and Tester from filename
  file_info2 <- extract_info(file_path2)
  
  # Add extracted columns
  df2 <- df2 %>%
    mutate(CV = file_info2$cv, 
           Tester = file_info2$tester)
  
  return(df2)
}

# Apply function to all files and combine into one dataframe
all_data2 <- bind_rows(lapply(file_list2, process_file2))

combined_data <- bind_rows(all_data, all_data2)

# View the first few rows
head(combined_data)

################
combined_data <- combined_data %>%
  mutate(X = row_number())  # Sequential index
write_csv(combined_data, "D:/Fatma/Env Index Manuscript/Redo_RegressionMean/All.Pred.Ability.additive.csv")

# Summarize to match "All.Pred.Ability.csv" format
formatted_data <- combined_data %>%
  group_by(CV, Tester) %>%
  summarise(mean = round(mean(cor, na.rm = TRUE), 2),
            sd = round(sd(cor, na.rm = TRUE), 2),
            .groups = "drop") %>%
  as.data.frame()


all <- combined_data

out <- all %>% group_by(CV,Tester) %>% dplyr::summarise(mean =round(mean(cor),2) ,
                                                        sd =round(sd(cor),2)) %>% as.data.frame()
out

library(ggplot2)
out$CV <- factor(out$CV ,levels = c("CV1", "CV2", "CV0", "CV00"))



p <- ggplot(out, aes(x=Tester, y=mean, fill=CV)) +
  geom_bar(stat="identity", position=position_dodge()) +
  geom_text(aes(label=paste(sprintf("%.2f", mean), "\u00B1",  sprintf("%.2f", sd), sep=" "),  y=0.1),
            position=position_dodge(0.9),  angle=90, color="white")+
  geom_errorbar(aes(ymin=mean, ymax=mean+sd), width=.2,
                position=position_dodge(.9)) +
  scale_y_continuous("Prediction ability")+
  scale_x_discrete("Population")+
  scale_fill_brewer(palette="Set2")
p


jpeg("D:/Fatma/Env Index Manuscript/Redo_RegressionMean/Pred.Ability.additive.jpeg", width = 6,height =4.5,units = "in", res=500)
p
dev.off()

##################
##################
##################
##################


df <- combined_data

df <- df %>% group_by(CV,Tester) %>% dplyr::summarise(mean =round(mean(cor),2) ,
                                                      sd =round(sd(cor),2)) %>% as.data.frame()
df

library(ggplot2)
df$CV <- factor(df$CV ,levels = c("CV1", "CV2", "CV0", "CV00"))

df$facet <- df$CV

df$facet <- gsub("CV1", "Unested hybrids in \ntested environments", df$facet)
df$facet <- gsub("CV2", "Tested hybrids in \ntested environments", df$facet)
df$facet <- gsub("CV00", "Untested hybrids in \nuntested environments", df$facet)
df$facet <- gsub("CV0", "Tested hybrids in \nuntested environments", df$facet)

head(df)

df$facet <- factor(df$facet ,levels = c("Tested hybrids in \ntested environments",
                                        "Unested hybrids in \ntested environments",
                                        "Tested hybrids in \nuntested environments",
                                        "Untested hybrids in \nuntested environments"))

p <- ggplot(df, aes(x=Tester, y=mean, fill=Tester)) +
  geom_bar(stat="identity", position=position_dodge()) +
  geom_text(aes(label=paste(sprintf("%.2f", mean),  "\u00B1",  sprintf("%.2f", sd), sep=" "),   y=0.12),
            position=position_dodge(0.9),  angle=90, color="black", size=3.5)+
  geom_errorbar(aes(ymin=mean, ymax=mean+sd), width=.2,
                position=position_dodge(.9)) +
  facet_wrap(~facet)+
  scale_y_continuous("Prediction ability")+
  scale_x_discrete("Population")+
  scale_fill_brewer(palette="Set2")+
  theme(legend.position = c(0.9,0.35),
        legend.background = element_blank())
p


jpeg("D:/Fatma/Env Index Manuscript/Redo_RegressionMean/Pred.Ability.additive.jpeg", width = 5,height =7,units = "in", res=500)
p
dev.off()

# Save formatted data
write_csv(formatted_data, "D:/Fatma/Env Index Manuscript/Redo_RegressionMean/All.Pred.Ability.additive.Formatted.csv")

print("All files combined and formatted successfully!")
