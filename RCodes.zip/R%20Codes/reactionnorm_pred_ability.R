library(dplyr)
####################

folder_path3 <- "D:\\Fatma\\Env Index Manuscript\\Redo_RegressionMean\\combined_data_reaction_norm"
file_list3 <- list.files(path = folder_path3, pattern = "*.csv", full.names = TRUE)


# Function to extract CV and Tester from the filename
extract_info <- function(file_path3) {
  file_name3 <- basename(file_path3)  # Get filename only
  
  # Extract CV (CV00, CV1, etc.)
  cv_match3 <- str_extract(file_name3, "CV[0-9]+")
  
  # Extract Tester (e.g., PHK76) - assuming it's the last part before ".csv"
  tester_match3 <- str_extract(file_name3, "[a-z]+[0-9]+(?=\\.csv)")
  
  return(list(cv = cv_match3, tester = tester_match3))
}

# Function to process each file
process_file3 <- function(file_path3) {
  df3 <- read_csv(file_path3, show_col_types = FALSE)  # Read CSV
  
  # Extract CV and Tester from filename
  file_info3 <- extract_info(file_path3)
  
  # Add extracted columns
  df3 <- df3 %>%
    mutate(CV = file_info3$cv, 
           Tester = file_info3$tester)
  
  return(df3)
}

# Apply function to all files and combine into one dataframe
all_data3 <- bind_rows(lapply(file_list3, process_file3))

all_data3 <- all_data3 %>%
  mutate(X = row_number())  # Sequential index
write_csv(all_data3, "D:/Fatma/Env Index Manuscript/Redo_RegressionMean/All.Pred.Ability.reactionnorm.csv")

# Summarize to match "All.Pred.Ability.csv" format
formatted_data <- all_data3 %>%
  group_by(CV, Tester) %>%
  summarise(mean = round(mean(cor, na.rm = TRUE), 2),
            sd = round(sd(cor, na.rm = TRUE), 2),
            .groups = "drop") %>%
  as.data.frame()


####################
all <- all_data3

out <- all %>% group_by(CV,Tester) %>% dplyr::summarise(mean =round(mean(cor),2) ,
                                                        sd =round(sd(cor),2)) %>% as.data.frame()
out

library(ggplot2)
out$CV <- factor(out$CV ,levels = c("CV1", "CV2", "CV0", "CV00"))



p <- ggplot(out, aes(x=Tester, y=mean, fill=CV)) +
  geom_bar(stat="identity", position=position_dodge()) +
  geom_text(aes(label=paste(sprintf("%.2f", mean), "\u00B1",  sprintf("%.2f", sd), sep=" "),  y=0.1),
            position=position_dodge(0.9),  angle=90, color="white")+
  geom_errorbar(aes(ymin=mean, ymax=mean+sd), width=.2,
                position=position_dodge(.9)) +
  scale_y_continuous("Prediction ability")+
  scale_x_discrete("Population")+
  scale_fill_brewer(palette="Set2")
p


jpeg("D:\\Fatma\\Env Index Manuscript\\Redo_RegressionMean\\Pred.Ability.reactionnorm.jpeg", width = 6,height =4.5,units = "in", res=500)
p
dev.off()

##################
##################
##################
##################


df <- all_data3

df <- df %>% group_by(CV,Tester) %>% dplyr::summarise(mean =round(mean(cor),2) ,
                                                      sd =round(sd(cor),2)) %>% as.data.frame()
df

library(ggplot2)
df$CV <- factor(df$CV ,levels = c("CV1", "CV2", "CV0", "CV00"))

df$facet <- df$CV

df$facet <- gsub("CV1", "Untested hybrids in \ntested environments", df$facet)
df$facet <- gsub("CV2", "Tested hybrids in \ntested environments", df$facet)
df$facet <- gsub("CV00", "Untested hybrids in \nuntested environments", df$facet)
df$facet <- gsub("CV0", "Tested hybrids in \nuntested environments", df$facet)

head(df)

df$facet <- factor(df$facet ,levels = c("Tested hybrids in \ntested environments",
                                        "Untested hybrids in \ntested environments",
                                        "Tested hybrids in \nuntested environments",
                                        "Untested hybrids in \nuntested environments"))

p <- ggplot(df, aes(x=Tester, y=mean, fill=Tester)) +
  geom_bar(stat="identity", position=position_dodge()) +
  geom_text(aes(label=paste(sprintf("%.2f", mean),  "\u00B1",  sprintf("%.2f", sd), sep=" "),   y=0.12),
            position=position_dodge(0.9),  angle=90, color="black", size=3.5)+
  geom_errorbar(aes(ymin=mean, ymax=mean+sd), width=.2,
                position=position_dodge(.9)) +
  facet_wrap(~facet)+
  scale_y_continuous("Prediction ability")+
  scale_x_discrete("Population")+
  scale_fill_brewer(palette="Set2")+
  theme(legend.position = c(0.9,0.35),
        legend.background = element_blank())
p


jpeg("D:\\Fatma\\Env Index Manuscript\\Redo_RegressionMean\\Pred.Ability.reaction_norm.jpeg", width = 5,height =7,units = "in", res=500)
p
dev.off()

write_csv(formatted_data, "D:/Fatma/Env Index Manuscript/Redo_RegressionMean/All.Pred.Ability.reactionnorm.Formatted.csv")
